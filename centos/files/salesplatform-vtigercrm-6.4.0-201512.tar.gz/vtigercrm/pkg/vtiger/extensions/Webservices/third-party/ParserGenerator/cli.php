<?php
require_once 'PHP/ParserGenerator.php';
$me = new PHP_ParserGenerator;
$me->main();
?>